<?php $__env->startSection('title', 'لوحة التحكم'); ?>
<?php $__env->startSection('page-title', 'لوحة التحكم الرئيسية'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">
    <!-- Quick Stats -->
    <?php echo $__env->make('admin.dashboard.stats', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    
    <!-- Charts Row -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-6">
        <?php echo $__env->make('admin.dashboard.charts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
    
    <!-- Recent Activity -->
    <div class="grid grid-cols-1 xl:grid-cols-3 gap-4 lg:gap-6">
        <?php echo $__env->make('admin.dashboard.recent-articles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('admin.dashboard.recent-activity', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // Dashboard specific JavaScript
    document.addEventListener('DOMContentLoaded', function() {
        // Auto-refresh stats every 30 seconds
        setInterval(() => {
            // You can implement AJAX refresh here
            console.log('Refreshing dashboard stats...');
        }, 30000);
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\newsroom\backend\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>