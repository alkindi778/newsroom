<?php $__env->startSection('title', 'سلة المهملات'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-6">
    <!-- Header -->
    <div class="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-6 space-y-4 lg:space-y-0">
        <div>
            <h1 class="text-xl sm:text-2xl font-bold text-gray-900 mb-2">سلة المهملات</h1>
            <p class="text-sm sm:text-base text-gray-600">إدارة المحتوى المحذوف - يمكن استعادته أو حذفه نهائياً</p>
        </div>
        
        <?php if((isset($articles) && $articles->count() > 0) || (isset($videos) && $videos->count() > 0)): ?>
        <div class="flex flex-col sm:flex-row gap-2 w-full lg:w-auto">
            <button onclick="bulkAction('restore')" 
                    class="px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 shadow-md">
                <svg class="w-4 h-4 inline ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6L9 4"></path>
                </svg>
                استعادة المحدد
            </button>
            <button onclick="bulkAction('force_delete')" 
                    class="px-4 py-2 bg-red-600 text-white text-sm font-medium rounded-lg hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 shadow-md">
                <svg class="w-4 h-4 inline ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
                حذف نهائي للمحدد
            </button>
            <button onclick="emptyTrash()" 
                    class="px-4 py-2 bg-red-800 text-white text-sm font-medium rounded-lg hover:bg-red-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 shadow-lg border border-red-700">
                <svg class="w-4 h-4 inline ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                </svg>
                إفراغ السلة بالكامل
            </button>
        </div>
        <?php endif; ?>
    </div>

    <!-- Tabs -->
    <div class="mb-6">
        <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-1 inline-flex gap-1">
            <a href="<?php echo e(route('admin.trash.index', ['type' => 'articles'])); ?>" 
               class="group relative flex items-center gap-3 px-6 py-3 rounded-md text-sm font-medium transition-all duration-200 <?php if($type === 'articles'): ?> bg-gradient-to-r from-blue-600 to-blue-700 text-white shadow-md <?php else: ?> text-gray-600 hover:bg-gray-50 hover:text-gray-900 <?php endif; ?>">
                <i class="fas fa-newspaper text-lg transition-transform duration-200 <?php if($type === 'articles'): ?> <?php else: ?> group-hover:scale-110 <?php endif; ?>"></i>
                <span>الأخبار</span>
                <?php if(isset($articles)): ?>
                    <span class="<?php if($type === 'articles'): ?> bg-white/20 text-white border border-white/30 <?php else: ?> bg-gray-100 text-gray-700 border border-gray-200 <?php endif; ?> inline-flex items-center justify-center min-w-[24px] h-6 px-2 rounded-full text-xs font-bold transition-all duration-200">
                        <?php echo e($articles->total()); ?>

                    </span>
                <?php endif; ?>
                <?php if($type === 'articles'): ?>
                    <div class="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-1/2 w-2 h-2 bg-blue-600 rounded-full"></div>
                <?php endif; ?>
            </a>
            
            <a href="<?php echo e(route('admin.trash.index', ['type' => 'videos'])); ?>" 
               class="group relative flex items-center gap-3 px-6 py-3 rounded-md text-sm font-medium transition-all duration-200 <?php if($type === 'videos'): ?> bg-gradient-to-r from-purple-600 to-purple-700 text-white shadow-md <?php else: ?> text-gray-600 hover:bg-gray-50 hover:text-gray-900 <?php endif; ?>">
                <i class="fas fa-video text-lg transition-transform duration-200 <?php if($type === 'videos'): ?> <?php else: ?> group-hover:scale-110 <?php endif; ?>"></i>
                <span>الفيديوهات</span>
                <?php if(isset($videos)): ?>
                    <span class="<?php if($type === 'videos'): ?> bg-white/20 text-white border border-white/30 <?php else: ?> bg-gray-100 text-gray-700 border border-gray-200 <?php endif; ?> inline-flex items-center justify-center min-w-[24px] h-6 px-2 rounded-full text-xs font-bold transition-all duration-200">
                        <?php echo e($videos->total()); ?>

                    </span>
                <?php endif; ?>
                <?php if($type === 'videos'): ?>
                    <div class="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-1/2 w-2 h-2 bg-purple-600 rounded-full"></div>
                <?php endif; ?>
            </a>
        </div>
    </div>

    <!-- Filters -->
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
        <form method="GET" action="<?php echo e(route('admin.trash.index')); ?>" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <input type="hidden" name="type" value="<?php echo e($type); ?>">
            
            <!-- Search -->
            <div>
                <label for="search" class="block text-sm font-medium text-gray-700 mb-1">البحث</label>
                <input type="text" 
                       id="search" 
                       name="search" 
                       value="<?php echo e(request('search')); ?>"
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                       placeholder="البحث في العنوان..."
                       onchange="this.form.submit()">
            </div>

            <!-- Category Filter (Articles only) -->
            <?php if($type === 'articles' && isset($categories)): ?>
            <div>
                <label for="category_id" class="block text-sm font-medium text-gray-700 mb-1">القسم</label>
                <select id="category_id" 
                        name="category_id" 
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        onchange="this.form.submit()">
                    <option value="">جميع الأقسام</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>" <?php echo e(request('category_id') == $category->id ? 'selected' : ''); ?>>
                        <?php echo e($category->name); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <?php endif; ?>

            <!-- Date From -->
            <div>
                <label for="date_from" class="block text-sm font-medium text-gray-700 mb-1">من تاريخ</label>
                <input type="date" 
                       id="date_from" 
                       name="date_from" 
                       value="<?php echo e(request('date_from')); ?>"
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                       onchange="this.form.submit()">
            </div>

            <!-- Date To -->
            <div>
                <label for="date_to" class="block text-sm font-medium text-gray-700 mb-1">إلى تاريخ</label>
                <input type="date" 
                       id="date_to" 
                       name="date_to" 
                       value="<?php echo e(request('date_to')); ?>"
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                       onchange="this.form.submit()">
            </div>
        </form>

        <?php if(request()->hasAny(['search', 'category_id', 'date_from', 'date_to'])): ?>
        <div class="mt-4 pt-4 border-t border-gray-200">
            <a href="<?php echo e(route('admin.trash.index')); ?>" 
               class="inline-flex items-center px-3 py-1 border border-gray-300 rounded-full text-sm text-gray-700 bg-white hover:bg-gray-50">
                <svg class="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
                مسح الفلاتر
            </a>
        </div>
        <?php endif; ?>
    </div>

    <!-- Content List -->
    <div class="bg-white rounded-lg shadow-sm border border-gray-200">
        <?php if($type === 'articles' && isset($articles) && $articles->count() > 0): ?>
        <!-- Bulk Actions Form -->
        <form id="bulk-form" method="POST">
            <?php echo csrf_field(); ?>
            
            <!-- Desktop Table View -->
            <div class="hidden lg:block overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                <input type="checkbox" id="select-all" class="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                            </th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                العنوان
                            </th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                القسم
                            </th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                الكاتب
                            </th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                تاريخ الحذف
                            </th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                الإجراءات
                            </th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <input type="checkbox" name="article_ids[]" value="<?php echo e($article->id); ?>" class="article-checkbox rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                            </td>
                            <td class="px-6 py-4">
                                <div class="flex items-center">
                                    <?php if($article->image): ?>
                                    <img class="h-12 w-12 rounded-lg object-cover ml-4 flex-shrink-0" 
                                         src="<?php echo e(asset('storage/' . $article->image)); ?>" 
                                         alt="<?php echo e($article->title); ?>">
                                    <?php else: ?>
                                    <div class="h-12 w-12 rounded-lg bg-gray-200 flex items-center justify-center ml-4 flex-shrink-0">
                                        <svg class="h-6 w-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                                        </svg>
                                    </div>
                                    <?php endif; ?>
                                    <div class="min-w-0 flex-1">
                                        <p class="text-sm font-medium text-gray-900 truncate"><?php echo e($article->title); ?></p>
                                        <?php if($article->subtitle): ?>
                                        <p class="text-sm text-gray-500 truncate"><?php echo e($article->subtitle); ?></p>
                                        <?php endif; ?>
                                        <?php if($article->source): ?>
                                        <p class="text-xs text-blue-600"><?php echo e($article->source); ?></p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <?php if($article->category): ?>
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                    <?php echo e($article->category->name); ?>

                                </span>
                                <?php else: ?>
                                <span class="text-gray-400 text-sm">غير محدد</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <?php echo e($article->user->name ?? 'غير محدد'); ?>

                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <?php echo e($article->deleted_at->format('Y/m/d H:i')); ?>

                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-left text-sm font-medium">
                                <div class="flex items-center space-x-2 space-x-reverse">
                                    <a href="<?php echo e(route('admin.trash.restore', $article->id)); ?>" 
                                       onclick="return confirm('هل تريد استعادة هذا الخبر؟')"
                                       class="text-green-600 hover:text-green-900 text-sm font-medium">
                                        استعادة
                                    </a>
                                    <span class="text-gray-300">|</span>
                                    <a href="<?php echo e(route('admin.trash.force-delete', $article->id)); ?>" 
                                       onclick="return confirm('تحذير: سيتم حذف الخبر نهائياً ولن يمكن استعادته. هل تريد المتابعة؟')"
                                       class="text-red-600 hover:text-red-900 text-sm font-medium">
                                        حذف نهائي
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                
                <!-- Desktop Pagination -->
                <?php if($articles->hasPages()): ?>
                <div class="px-6 py-4 border-t border-gray-200">
                    <?php echo e($articles->links()); ?>

                </div>
                <?php endif; ?>
            </div>
            
            <!-- Mobile Card View -->
            <div class="lg:hidden">
                <div class="p-4 border-b border-gray-200 bg-gray-50">
                    <label class="flex items-center">
                        <input type="checkbox" id="select-all-mobile" class="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50 ml-2">
                        <span class="text-sm font-medium text-gray-700">تحديد الكل</span>
                    </label>
                </div>
                
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="border-b border-gray-200 p-4 hover:bg-gray-50">
                    <div class="flex items-start space-x-4 space-x-reverse">
                        <!-- Checkbox -->
                        <input type="checkbox" name="article_ids[]" value="<?php echo e($article->id); ?>" class="article-checkbox-mobile rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50 mt-1">
                        
                        <!-- Image -->
                        <div class="flex-shrink-0">
                            <?php if($article->image): ?>
                            <img class="h-16 w-16 rounded-lg object-cover" 
                                 src="<?php echo e(asset('storage/' . $article->image)); ?>" 
                                 alt="<?php echo e($article->title); ?>">
                            <?php else: ?>
                            <div class="h-16 w-16 rounded-lg bg-gray-200 flex items-center justify-center">
                                <svg class="h-8 w-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                                </svg>
                            </div>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Content -->
                        <div class="flex-1 min-w-0 mr-3">
                            <div class="flex items-start justify-between">
                                <div class="flex-1">
                                    <h3 class="text-sm font-medium text-gray-900 line-clamp-2"><?php echo e($article->title); ?></h3>
                                    <?php if($article->subtitle): ?>
                                    <p class="text-sm text-gray-500 mt-1 line-clamp-1"><?php echo e($article->subtitle); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <!-- Meta Info -->
                            <div class="mt-2 flex flex-wrap gap-2 text-xs">
                                <?php if($article->category): ?>
                                <span class="inline-flex items-center px-2 py-1 rounded-full bg-blue-100 text-blue-800 font-medium">
                                    <?php echo e($article->category->name); ?>

                                </span>
                                <?php endif; ?>
                                <?php if($article->source): ?>
                                <span class="inline-flex items-center px-2 py-1 rounded-full bg-gray-100 text-gray-700">
                                    <?php echo e($article->source); ?>

                                </span>
                                <?php endif; ?>
                                <span class="text-gray-500">
                                    بواسطة: <?php echo e($article->user->name ?? 'غير محدد'); ?>

                                </span>
                                <span class="text-gray-500">
                                    حُذف: <?php echo e($article->deleted_at->format('M d, H:i')); ?>

                                </span>
                            </div>
                            
                            <!-- Actions -->
                            <div class="mt-3 flex space-x-2 space-x-reverse">
                                <a href="<?php echo e(route('admin.trash.restore', $article->id)); ?>" 
                                   onclick="return confirm('هل تريد استعادة هذا الخبر؟')"
                                   class="inline-flex items-center px-3 py-1 border border-green-300 rounded-md text-xs font-medium text-green-700 bg-green-50 hover:bg-green-100">
                                    <svg class="w-3 h-3 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6L9 4"></path>
                                    </svg>
                                    استعادة
                                </a>
                                <a href="<?php echo e(route('admin.trash.force-delete', $article->id)); ?>" 
                                   onclick="return confirm('تحذير: سيتم حذف الخبر نهائياً ولن يمكن استعادته. هل تريد المتابعة؟')"
                                   class="inline-flex items-center px-3 py-1 border border-red-300 rounded-md text-xs font-medium text-red-700 bg-red-50 hover:bg-red-100">
                                    <svg class="w-3 h-3 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                                    </svg>
                                    حذف نهائي
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <!-- Mobile Pagination -->
                <?php if($articles->hasPages()): ?>
                <div class="px-4 py-4 border-t border-gray-200">
                    <?php echo e($articles->links()); ?>

                </div>
                <?php endif; ?>
            </div>
        </form>

        <?php elseif($type === 'videos' && isset($videos) && $videos->count() > 0): ?>
        <!-- Videos List -->
        <form id="bulk-form" method="POST">
            <?php echo csrf_field(); ?>
            
            <!-- Desktop Table View -->
            <div class="hidden lg:block overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                <input type="checkbox" id="select-all" class="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-300 focus:ring focus:ring-blue-200 focus:ring-opacity-50">
                            </th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                العنوان
                            </th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                النوع
                            </th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                المدة
                            </th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                تاريخ الحذف
                            </th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                الإجراءات
                            </th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <input type="checkbox" name="video_ids[]" value="<?php echo e($video->id); ?>" class="video-checkbox rounded border-gray-300 text-blue-600 shadow-sm">
                            </td>
                            <td class="px-6 py-4">
                                <div class="flex items-center">
                                    <img class="h-12 w-16 rounded-lg object-cover ml-4 flex-shrink-0" 
                                         src="<?php echo e($video->thumbnail_url); ?>" 
                                         alt="<?php echo e($video->title); ?>">
                                    <div class="min-w-0 flex-1">
                                        <p class="text-sm font-medium text-gray-900 truncate"><?php echo e($video->title); ?></p>
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                                    <?php echo e(ucfirst($video->video_type)); ?>

                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <?php echo e($video->duration ?? '-'); ?>

                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <?php echo e($video->deleted_at->format('Y/m/d H:i')); ?>

                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-left text-sm font-medium">
                                <div class="flex items-center space-x-2 space-x-reverse">
                                    <a href="<?php echo e(route('admin.trash.video.restore', $video->id)); ?>" 
                                       onclick="return confirm('هل تريد استعادة هذا الفيديو؟')"
                                       class="text-green-600 hover:text-green-900 text-sm font-medium">
                                        استعادة
                                    </a>
                                    <span class="text-gray-300">|</span>
                                    <a href="<?php echo e(route('admin.trash.video.force-delete', $video->id)); ?>" 
                                       onclick="return confirm('تحذير: سيتم حذف الفيديو نهائياً ولن يمكن استعادته. هل تريد المتابعة؟')"
                                       class="text-red-600 hover:text-red-900 text-sm font-medium">
                                        حذف نهائي
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                
                <?php if($videos->hasPages()): ?>
                <div class="px-6 py-4 border-t border-gray-200">
                    <?php echo e($videos->appends(['type' => 'videos'])->links()); ?>

                </div>
                <?php endif; ?>
            </div>
        </form>

        <?php else: ?>
        <!-- Empty State -->
        <div class="text-center py-12">
            <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
            </svg>
            <h3 class="mt-4 text-lg font-medium text-gray-900">سلة المهملات فارغة</h3>
            <p class="mt-2 text-gray-500">
                <?php if($type === 'videos'): ?>
                    لا توجد فيديوهات محذوفة حالياً
                <?php else: ?>
                    لا توجد أخبار محذوفة حالياً
                <?php endif; ?>
            </p>
            <div class="mt-6">
                <?php if($type === 'videos'): ?>
                    <a href="<?php echo e(route('admin.videos.index')); ?>" 
                       class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">
                        العودة للفيديوهات
                    </a>
                <?php else: ?>
                    <a href="<?php echo e(route('admin.articles.index')); ?>" 
                       class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">
                        العودة للأخبار
                    </a>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.line-clamp-1 {
    display: -webkit-box;
    -webkit-line-clamp: 1;
    -webkit-box-orient: vertical;
    overflow: hidden;
}
.line-clamp-2 {
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
const currentType = '<?php echo e($type); ?>';

// Select All functionality for desktop
document.getElementById('select-all')?.addEventListener('change', function() {
    const checkboxClass = currentType === 'videos' ? '.video-checkbox' : '.article-checkbox';
    const checkboxes = document.querySelectorAll(checkboxClass);
    checkboxes.forEach(checkbox => {
        checkbox.checked = this.checked;
    });
});

// Select All functionality for mobile
document.getElementById('select-all-mobile')?.addEventListener('change', function() {
    const checkboxClass = currentType === 'videos' ? '.video-checkbox-mobile' : '.article-checkbox-mobile';
    const checkboxes = document.querySelectorAll(checkboxClass);
    checkboxes.forEach(checkbox => {
        checkbox.checked = this.checked;
    });
});

// Bulk Actions
function bulkAction(action) {
    const checkboxClass = currentType === 'videos' ? '.video-checkbox' : '.article-checkbox';
    const checkedBoxes = document.querySelectorAll(checkboxClass + ':checked');
    
    if (checkedBoxes.length === 0) {
        alert(currentType === 'videos' ? 'يرجى اختيار فيديو واحد على الأقل' : 'يرجى اختيار خبر واحد على الأقل');
        return;
    }

    const itemType = currentType === 'videos' ? 'فيديو' : 'خبر';
    let confirmMessage = '';
    let actionUrl = '';
    
    if (action === 'restore') {
        confirmMessage = `هل تريد استعادة ${checkedBoxes.length} ${itemType}؟`;
        actionUrl = '<?php echo e(route("admin.trash.bulk-restore")); ?>';
    } else if (action === 'force_delete') {
        confirmMessage = `تحذير: سيتم حذف ${checkedBoxes.length} ${itemType} نهائياً ولن يمكن استعادتها. هل تريد المتابعة؟`;
        actionUrl = '<?php echo e(route("admin.trash.bulk-force-delete")); ?>';
    }

    if (confirm(confirmMessage)) {
        const form = document.getElementById('bulk-form');
        form.action = actionUrl;
        form.submit();
    }
}

// Empty Trash
function emptyTrash() {
    const itemType = currentType === 'videos' ? 'الفيديوهات' : 'الأخبار';
    if (confirm(`⚠️ تحذير خطير!\n\nسيتم حذف جميع ${itemType} في سلة المهملات نهائياً ولن يمكن استعادتها أبداً.\n\nهل أنت متأكد من أنك تريد إفراغ سلة المهملات بالكامل؟`)) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = '<?php echo e(route("admin.trash.empty")); ?>?type=' + currentType;
        
        const csrfToken = document.createElement('input');
        csrfToken.type = 'hidden';
        csrfToken.name = '_token';
        csrfToken.value = '<?php echo e(csrf_token()); ?>';
        
        const typeInput = document.createElement('input');
        typeInput.type = 'hidden';
        typeInput.name = 'type';
        typeInput.value = currentType;
        
        form.appendChild(csrfToken);
        form.appendChild(typeInput);
        document.body.appendChild(form);
        form.submit();
    }
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\newsroom\backend\resources\views/admin/trash/index.blade.php ENDPATH**/ ?>