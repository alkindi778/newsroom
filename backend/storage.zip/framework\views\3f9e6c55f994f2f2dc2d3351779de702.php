<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['paginator', 'class' => '']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['paginator', 'class' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php if($paginator->hasPages()): ?>
    
    <nav class="hidden sm:flex items-center justify-between border-t border-gray-200 bg-white px-4 py-3 sm:px-6 <?php echo e($class); ?>" aria-label="Pagination">
        <div class="hidden sm:block">
            <p class="text-sm text-gray-700">
                عرض
                <span class="font-medium"><?php echo e($paginator->firstItem()); ?></span>
                إلى
                <span class="font-medium"><?php echo e($paginator->lastItem()); ?></span>
                من
                <span class="font-medium"><?php echo e($paginator->total()); ?></span>
                نتيجة
            </p>
        </div>
        <div class="flex flex-1 justify-between sm:justify-end">
            
            <?php if($paginator->onFirstPage()): ?>
                <span class="relative inline-flex items-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-500 cursor-not-allowed">السابق</span>
            <?php else: ?>
                <a href="<?php echo e($paginator->previousPageUrl()); ?>" 
                   class="relative inline-flex items-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:z-10 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500">
                    السابق
                </a>
            <?php endif; ?>

            
            <div class="hidden md:-mt-px md:flex">
                <?php $__currentLoopData = $paginator->getUrlRange(1, $paginator->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $paginator->currentPage()): ?>
                        <span class="relative z-10 inline-flex items-center border border-blue-500 bg-blue-50 px-4 py-2 text-sm font-medium text-blue-600 focus:z-20" aria-current="page"><?php echo e($page); ?></span>
                    <?php else: ?>
                        <a href="<?php echo e($url); ?>" 
                           class="relative inline-flex items-center border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-500 hover:bg-gray-50 focus:z-10 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500">
                            <?php echo e($page); ?>

                        </a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            
            <?php if($paginator->hasMorePages()): ?>
                <a href="<?php echo e($paginator->nextPageUrl()); ?>" 
                   class="relative mr-3 inline-flex items-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:z-10 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500">
                    التالي
                </a>
            <?php else: ?>
                <span class="relative mr-3 inline-flex items-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-500 cursor-not-allowed">التالي</span>
            <?php endif; ?>
        </div>
    </nav>

    
    <div class="flex items-center justify-between border-t border-gray-200 bg-white px-4 py-3 sm:hidden">
        <div class="flex flex-1 justify-between">
            <?php if($paginator->onFirstPage()): ?>
                <span class="relative inline-flex items-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-500 cursor-not-allowed">السابق</span>
            <?php else: ?>
                <a href="<?php echo e($paginator->previousPageUrl()); ?>" 
                   class="relative inline-flex items-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50">
                    السابق
                </a>
            <?php endif; ?>

            <span class="relative inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700">
                <?php echo e($paginator->currentPage()); ?> من <?php echo e($paginator->lastPage()); ?>

            </span>

            <?php if($paginator->hasMorePages()): ?>
                <a href="<?php echo e($paginator->nextPageUrl()); ?>" 
                   class="relative inline-flex items-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50">
                    التالي
                </a>
            <?php else: ?>
                <span class="relative inline-flex items-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-500 cursor-not-allowed">التالي</span>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\newsroom\backend\resources\views/components/admin/pagination.blade.php ENDPATH**/ ?>