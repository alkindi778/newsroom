<!-- Success Message -->
<?php if (isset($component)) { $__componentOriginal24e5bcaff3516a0985758ac92cc6fd3a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal24e5bcaff3516a0985758ac92cc6fd3a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.success-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.success-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal24e5bcaff3516a0985758ac92cc6fd3a)): ?>
<?php $attributes = $__attributesOriginal24e5bcaff3516a0985758ac92cc6fd3a; ?>
<?php unset($__attributesOriginal24e5bcaff3516a0985758ac92cc6fd3a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal24e5bcaff3516a0985758ac92cc6fd3a)): ?>
<?php $component = $__componentOriginal24e5bcaff3516a0985758ac92cc6fd3a; ?>
<?php unset($__componentOriginal24e5bcaff3516a0985758ac92cc6fd3a); ?>
<?php endif; ?>

<!-- Error Message -->
<?php if (isset($component)) { $__componentOriginal57b9d9b78f2e3eb07154dea7a92e1f78 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal57b9d9b78f2e3eb07154dea7a92e1f78 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.error-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.error-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal57b9d9b78f2e3eb07154dea7a92e1f78)): ?>
<?php $attributes = $__attributesOriginal57b9d9b78f2e3eb07154dea7a92e1f78; ?>
<?php unset($__attributesOriginal57b9d9b78f2e3eb07154dea7a92e1f78); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal57b9d9b78f2e3eb07154dea7a92e1f78)): ?>
<?php $component = $__componentOriginal57b9d9b78f2e3eb07154dea7a92e1f78; ?>
<?php unset($__componentOriginal57b9d9b78f2e3eb07154dea7a92e1f78); ?>
<?php endif; ?>

<!-- Info Message -->
<?php if (isset($component)) { $__componentOriginala2b9818688e9a6c11eaa99597d409d32 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala2b9818688e9a6c11eaa99597d409d32 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.info-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.info-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala2b9818688e9a6c11eaa99597d409d32)): ?>
<?php $attributes = $__attributesOriginala2b9818688e9a6c11eaa99597d409d32; ?>
<?php unset($__attributesOriginala2b9818688e9a6c11eaa99597d409d32); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala2b9818688e9a6c11eaa99597d409d32)): ?>
<?php $component = $__componentOriginala2b9818688e9a6c11eaa99597d409d32; ?>
<?php unset($__componentOriginala2b9818688e9a6c11eaa99597d409d32); ?>
<?php endif; ?>

<!-- Warning Message -->
<?php if (isset($component)) { $__componentOriginal09eb2079b534b99dffc0ddafae8a7592 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal09eb2079b534b99dffc0ddafae8a7592 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.warning-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.warning-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal09eb2079b534b99dffc0ddafae8a7592)): ?>
<?php $attributes = $__attributesOriginal09eb2079b534b99dffc0ddafae8a7592; ?>
<?php unset($__attributesOriginal09eb2079b534b99dffc0ddafae8a7592); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal09eb2079b534b99dffc0ddafae8a7592)): ?>
<?php $component = $__componentOriginal09eb2079b534b99dffc0ddafae8a7592; ?>
<?php unset($__componentOriginal09eb2079b534b99dffc0ddafae8a7592); ?>
<?php endif; ?>

<!-- Validation Errors -->
<?php if($errors->any()): ?>
<div class="mb-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded-lg">
    <div class="flex items-center mb-2">
        <svg class="w-5 h-5 ml-2 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"></path>
        </svg>
        <h3 class="text-sm font-medium mr-3">يرجى تصحيح الأخطاء التالية:</h3>
    </div>
    <ul class="list-disc list-inside text-sm">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\newsroom\backend\resources\views/components/admin/alert-messages.blade.php ENDPATH**/ ?>